#include <fltKernel.h>
#include <ntddk.h>

#define USN_SHIELD_POOL_TAG 'dShU'

typedef struct _USN_SHIELD_STATE {
    UINT64 OldestEntry;
    UINT64 NextUsn;
    UINT64 JournalId;
    BOOLEAN Active;
} USN_SHIELD_STATE;

static USN_SHIELD_STATE g_State = { 0 };
static PFLT_FILTER g_FilterHandle = NULL;

static FLT_PREOP_CALLBACK_STATUS
UsnPreFsControl(
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Flt_CompletionContext_Outptr_ PVOID* CompletionContext
) {
    UNREFERENCED_PARAMETER(FltObjects);
    UNREFERENCED_PARAMETER(CompletionContext);

    if (Data->Iopb->Parameters.FileSystemControl.Common.FsControlCode
        != FSCTL_READ_USN_JOURNAL) {
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}

static FLT_POSTOP_CALLBACK_STATUS
UsnPostFsControl(
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _In_opt_ PVOID CompletionContext,
    _In_ FLT_POST_OPERATION_FLAGS Flags
) {
    UNREFERENCED_PARAMETER(FltObjects);
    UNREFERENCED_PARAMETER(CompletionContext);

    if (!NT_SUCCESS(Data->IoStatus.Status)) {
        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    if (Data->Iopb->Parameters.FileSystemControl.Common.FsControlCode
        != FSCTL_READ_USN_JOURNAL) {
        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    if (FlagOn(Flags, FLTFL_POST_OPERATION_DRAINING)) {
        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    if (!g_State.Active || g_State.OldestEntry == 0) {
        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    PVOID outBuf = Data->Iopb->Parameters.FileSystemControl.Neither.OutputBuffer;
    ULONG outLen = Data->Iopb->Parameters.FileSystemControl.Common.OutputBufferLength;

    if (outBuf == NULL || outLen <= sizeof(USN)) {
        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    PUCHAR p = (PUCHAR)outBuf + sizeof(USN);
    PUCHAR end = (PUCHAR)outBuf + outLen;

    while (p + sizeof(USN_RECORD_V2) <= end) {
        PUSN_RECORD_V2 rec = (PUSN_RECORD_V2)p;
        if (rec->RecordLength == 0) {
            break;
        }
        if (rec->RecordLength > (ULONG)(end - p)) {
            break;
        }
        if (rec->TimeStamp.QuadPart > (LONGLONG)g_State.OldestEntry) {
            rec->TimeStamp.QuadPart = (LONGLONG)g_State.OldestEntry;
        }
        p += rec->RecordLength;
    }

    return FLT_POSTOP_FINISHED_PROCESSING;
}

static NTSTATUS
FilterUnload(
    _In_ FLT_FILTER_UNLOAD_FLAGS Flags
) {
    UNREFERENCED_PARAMETER(Flags);
    if (g_FilterHandle != NULL) {
        FltUnregisterFilter(g_FilterHandle);
        g_FilterHandle = NULL;
    }
    return STATUS_SUCCESS;
}

static const FLT_OPERATION_REGISTRATION Callbacks[] = {
    { IRP_MJ_FILE_SYSTEM_CONTROL, 0, UsnPreFsControl, UsnPostFsControl },
    { IRP_MJ_OPERATION_END, 0, NULL, NULL }
};

static const FLT_REGISTRATION FilterRegistration = {
    sizeof(FLT_REGISTRATION),
    FLT_REGISTRATION_VERSION,
    0,
    NULL,
    Callbacks,
    FilterUnload,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
};

NTSTATUS
DriverEntry(
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath
) {
    UNREFERENCED_PARAMETER(RegistryPath);

    NTSTATUS status = FltRegisterFilter(DriverObject,
        &FilterRegistration,
        &g_FilterHandle);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    g_State.Active = TRUE;
    g_State.OldestEntry = 0;
    g_State.NextUsn = 0;
    g_State.JournalId = 0;

    status = FltStartFiltering(g_FilterHandle);
    if (!NT_SUCCESS(status)) {
        FltUnregisterFilter(g_FilterHandle);
        g_FilterHandle = NULL;
        return status;
    }

    return STATUS_SUCCESS;
}