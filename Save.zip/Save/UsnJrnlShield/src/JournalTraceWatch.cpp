#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include "JournalTraceWatch.h"
#include "UsnJournal.h"
#include "UsnRawPatch.h"
#include "Timestamps.h"
#include "Persist.h"

static bool IsJournalTraceRunning() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) {
        return false;
    }
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    bool found = false;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, L"JournalTrace.exe") == 0) {
                found = true;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

void RunWatchdog(const std::vector<std::wstring>& volumes) {
    wprintf(L"[watch] started, %zu volumes\n", volumes.size());
    while (true) {
        for (auto& v : volumes) {
            UsnState saved{};
            if (!PersistLoadState(v, saved)) {
                continue;
            }

            UsnState cur{};
            if (!QueryUsnState(v.c_str(), cur)) {
                continue;
            }

            if (cur.oldestEntry > saved.oldestEntry) {
                wprintf(L"[watch] [%s] Oldest entry drifted, re-applying\n",
                    v.c_str());
                RawPatchUsnJournal(v.c_str(), saved);
                RestoreSystemTimestamps(v.c_str());
            }
        }
        Sleep(2000);
    }
}