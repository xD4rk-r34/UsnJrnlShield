#pragma once
#include <string>
#include <vector>

void RunWatchdog(const std::vector<std::wstring>& volumes);