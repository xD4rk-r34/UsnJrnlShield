#include "VolumeEnum.h"

std::vector<std::wstring> EnumVolumes() {
    std::vector<std::wstring> out;

    wchar_t drives[512] = {};
    DWORD len = GetLogicalDriveStringsW(511, drives);
    if (len == 0) {
        return out;
    }

    wchar_t* p = drives;
    while (*p) {
        std::wstring drive = p;
        p += drive.length() + 1;

        if (drive.length() >= 2 && drive[1] == L':') {
            UINT type = GetDriveTypeW(drive.c_str());
            if (type == DRIVE_FIXED) {
                std::wstring vol = L"\\\\?\\";
                vol += drive.substr(0, 2);
                out.push_back(vol);
            }
        }
    }

    return out;
}