#pragma once
#include <windows.h>
#include <string>
#include "UsnJournal.h"

struct SavedTs {
    uint64_t creation;
    uint64_t access;
    uint64_t write;
};

bool PersistSaveState(const std::wstring& volume, const UsnState& st);
bool PersistLoadState(const std::wstring& volume, UsnState& out);
bool PersistSaveTimestamp(const std::wstring& file, const SavedTs& ts);
bool PersistLoadTimestamp(const std::wstring& file, SavedTs& out);