#include <windows.h>
#include <winioctl.h>
#include <string>
#include "UsnRawPatch.h"

static HANDLE OpenRawVolume(const wchar_t* vol) {
    std::wstring p = L"\\\\.\\";
    p += vol;
    return CreateFileW(p.c_str(), GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, 0, nullptr);
}

bool RawPatchUsnJournal(const wchar_t* volume, const UsnState& state) {
    (void)state;

    HANDLE h = OpenRawVolume(volume);
    if (h == INVALID_HANDLE_VALUE) {
        return false;
    }

    DWORD br = 0;

    if (!DeviceIoControl(h, FSCTL_LOCK_VOLUME, nullptr, 0,
        nullptr, 0, &br, nullptr)) {
        CloseHandle(h);
        return false;
    }

    DeviceIoControl(h, FSCTL_DISMOUNT_VOLUME, nullptr, 0,
        nullptr, 0, &br, nullptr);

    NTFS_VOLUME_DATA_BUFFER nvdb{};
    DeviceIoControl(h, FSCTL_GET_NTFS_VOLUME_DATA, nullptr, 0,
        &nvdb, sizeof(nvdb), &br, nullptr);

    DeviceIoControl(h, FSCTL_UNLOCK_VOLUME, nullptr, 0,
        nullptr, 0, &br, nullptr);
    CloseHandle(h);
    return false;
}