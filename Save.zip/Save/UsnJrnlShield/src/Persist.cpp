#include <windows.h>
#include "Persist.h"

static const wchar_t* kRegRoot = L"Software\\UsnJrnlShield";

bool PersistSaveState(const std::wstring& volume, const UsnState& st) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kRegRoot, 0, nullptr, 0,
        KEY_WRITE, nullptr, &k, nullptr) != ERROR_SUCCESS) {
        return false;
    }
    RegSetValueExW(k, volume.c_str(), 0, REG_BINARY,
        (const BYTE*)&st, sizeof(st));
    RegCloseKey(k);
    return true;
}

bool PersistLoadState(const std::wstring& volume, UsnState& out) {
    HKEY k;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kRegRoot, 0, KEY_READ, &k)
        != ERROR_SUCCESS) {
        return false;
    }
    DWORD sz = sizeof(out);
    DWORD type = 0;
    bool ok = RegQueryValueExW(k, volume.c_str(), nullptr, &type,
        (BYTE*)&out, &sz) == ERROR_SUCCESS;
    RegCloseKey(k);
    return ok;
}

bool PersistSaveTimestamp(const std::wstring& file, const SavedTs& ts) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kRegRoot, 0, nullptr, 0,
        KEY_WRITE, nullptr, &k, nullptr) != ERROR_SUCCESS) {
        return false;
    }
    RegSetValueExW(k, file.c_str(), 0, REG_BINARY,
        (const BYTE*)&ts, sizeof(ts));
    RegCloseKey(k);
    return true;
}

bool PersistLoadTimestamp(const std::wstring& file, SavedTs& out) {
    HKEY k;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kRegRoot, 0, KEY_READ, &k)
        != ERROR_SUCCESS) {
        return false;
    }
    DWORD sz = sizeof(out);
    DWORD type = 0;
    bool ok = RegQueryValueExW(k, file.c_str(), nullptr, &type,
        (BYTE*)&out, &sz) == ERROR_SUCCESS;
    RegCloseKey(k);
    return ok;
}