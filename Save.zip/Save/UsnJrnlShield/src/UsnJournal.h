#pragma once
#include <windows.h>
#include <string>
#include <cstdint>

struct UsnState {
    uint64_t journalId;
    uint64_t firstUsn;
    uint64_t nextUsn;
    uint64_t maximumSize;
    uint64_t allocationDelta;
    uint64_t oldestEntry;
    uint64_t entryCount;
    uint64_t fileCount;
    uint64_t dirCount;
};

bool QueryUsnState(const wchar_t* volume, UsnState& out);
bool WipeUsnJournal(const wchar_t* volume);