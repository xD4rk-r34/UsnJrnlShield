#include <windows.h>
#include <winioctl.h>
#include <vector>
#include "UsnJournal.h"

static HANDLE OpenVolumeForRead(const wchar_t* vol) {
    std::wstring path = L"\\\\.\\";
    std::wstring v = vol;
    if (v.rfind(L"\\\\?\\", 0) == 0) {
        v = v.substr(4);
    }
    path += v;
    if (!path.empty() && path.back() == L'\\') {
        path.pop_back();
    }
    return CreateFileW(path.c_str(), GENERIC_READ,
                       FILE_SHARE_READ | FILE_SHARE_WRITE,
                       nullptr, OPEN_EXISTING, 0, nullptr);
}

static HANDLE OpenVolumeForWrite(const wchar_t* vol) {
    std::wstring path = L"\\\\.\\";
    std::wstring v = vol;
    if (v.rfind(L"\\\\?\\", 0) == 0) {
        v = v.substr(4);
    }
    path += v;
    if (!path.empty() && path.back() == L'\\') {
        path.pop_back();
    }
    return CreateFileW(path.c_str(), GENERIC_READ | GENERIC_WRITE,
                       FILE_SHARE_READ | FILE_SHARE_WRITE,
                       nullptr, OPEN_EXISTING, 0, nullptr);
}

bool QueryUsnState(const wchar_t* volume, UsnState& out) {
    out = UsnState{};

    HANDLE h = OpenVolumeForRead(volume);
    if (h == INVALID_HANDLE_VALUE) {
        return false;
    }

    USN_JOURNAL_DATA_V0 jd{};
    DWORD br = 0;
    if (!DeviceIoControl(h, FSCTL_QUERY_USN_JOURNAL, nullptr, 0,
                         &jd, sizeof(jd), &br, nullptr)) {
        CloseHandle(h);
        return false;
    }

    out.journalId = jd.UsnJournalID;
    out.firstUsn = jd.FirstUsn;
    out.nextUsn = jd.NextUsn;
    out.maximumSize = jd.MaximumSize;
    out.allocationDelta = jd.AllocationDelta;

    READ_USN_JOURNAL_DATA_V0 rd{};
    rd.StartUsn = jd.FirstUsn;
    rd.ReasonMask = 0xFFFFFFFF;
    rd.ReturnOnlyOnClose = FALSE;
    rd.Timeout = 0;
    rd.BytesToWaitFor = 0;
    rd.UsnJournalID = jd.UsnJournalID;

    std::vector<BYTE> buf(1 << 20);
    uint64_t minTs = UINT64_MAX;

    while (true) {
        DWORD bytes = 0;
        BOOL ok = DeviceIoControl(h, FSCTL_READ_USN_JOURNAL,
                                  &rd, sizeof(rd),
                                  buf.data(), (DWORD)buf.size(),
                                  &bytes, nullptr);
        if (!ok || bytes <= sizeof(USN)) {
            break;
        }

        USN nextUsn = *reinterpret_cast<USN*>(buf.data());
        BYTE* p = buf.data() + sizeof(USN);
        BYTE* end = buf.data() + bytes;

        while (p + sizeof(USN_RECORD_V2) <= end) {
            USN_RECORD_V2* r = reinterpret_cast<USN_RECORD_V2*>(p);
            if (r->RecordLength == 0) {
                break;
            }

            uint64_t ts = (uint64_t)r->TimeStamp.QuadPart;
            if (ts < minTs) {
                minTs = ts;
            }
            out.entryCount++;
            if (r->FileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                out.dirCount++;
            } else {
                out.fileCount++;
            }

            p += r->RecordLength;
        }

        if (nextUsn == rd.StartUsn) {
            break;
        }
        rd.StartUsn = nextUsn;
    }

    if (minTs != UINT64_MAX) {
        out.oldestEntry = minTs;
    }

    CloseHandle(h);
    return true;
}

bool WipeUsnJournal(const wchar_t* volume) {
    HANDLE h = OpenVolumeForWrite(volume);
    if (h == INVALID_HANDLE_VALUE) {
        return false;
    }

    USN_JOURNAL_DATA_V0 jd{};
    DWORD br = 0;
    BOOL haveJd = DeviceIoControl(h, FSCTL_QUERY_USN_JOURNAL, nullptr, 0,
                                  &jd, sizeof(jd), &br, nullptr);

    DELETE_USN_JOURNAL_DATA del{};
    del.UsnJournalID = haveJd ? jd.UsnJournalID : 0;
    del.DeleteFlags = 0x00000001;
    DeviceIoControl(h, FSCTL_DELETE_USN_JOURNAL, &del, sizeof(del),
                    nullptr, 0, &br, nullptr);

    CREATE_USN_JOURNAL_DATA cj{};
    cj.MaximumSize = haveJd ? jd.MaximumSize : (32ull << 20);
    cj.AllocationDelta = haveJd ? jd.AllocationDelta : (4ull << 20);
    DeviceIoControl(h, FSCTL_CREATE_USN_JOURNAL, &cj, sizeof(cj),
                    nullptr, 0, &br, nullptr);

    CloseHandle(h);
    return true;
}