#pragma once
#include <windows.h>

typedef struct _FILE_BASIC_INFORMATION {
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    ULONG FileAttributes;
} FILE_BASIC_INFORMATION, * PFILE_BASIC_INFORMATION;

typedef LONG(NTAPI* PNT_SET_INFORMATION_FILE)(
    HANDLE FileHandle,
    PVOID IoStatusBlock,
    PVOID FileInformation,
    ULONG Length,
    ULONG FileInformationClass
    );

inline PNT_SET_INFORMATION_FILE LoadNtSetInformationFile() {
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll) return nullptr;
    return (PNT_SET_INFORMATION_FILE)GetProcAddress(ntdll, "NtSetInformationFile");
}