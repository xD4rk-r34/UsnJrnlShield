#include <windows.h>
#include <cstdio>
#include <string>
#include <vector>
#include "VolumeEnum.h"
#include "UsnJournal.h"
#include "UsnRawPatch.h"
#include "Timestamps.h"
#include "Persist.h"
#include "JournalTraceWatch.h"

static void PrintBanner() {
    wprintf(L"UsnJrnlShield v1.0\n");
    wprintf(L"Usage:\n");
    wprintf(L"  UsnJrnlShield snapshot   - save current USN state of all volumes\n");
    wprintf(L"  UsnJrnlShield wipe       - wipe logs and restore Oldest entry\n");
    wprintf(L"  UsnJrnlShield restore    - re-apply saved timestamps and USN state\n");
    wprintf(L"  UsnJrnlShield watch      - run as background watchdog\n");
    wprintf(L"  UsnJrnlShield status     - print current state\n");
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        PrintBanner();
        return 1;
    }

    std::wstring cmd = argv[1];
    std::vector<std::wstring> volumes = EnumVolumes();
    wprintf(L"[*] Found %zu volumes\n", volumes.size());

    if (cmd == L"snapshot") {
        for (auto& v : volumes) {
            UsnState st{};
            if (QueryUsnState(v.c_str(), st)) {
                PersistSaveState(v, st);
                wprintf(L"    [%s] UsnJournalID=0x%llX NextUsn=%lld MaxSize=%lld\n",
                    v.c_str(),
                    (unsigned long long)st.journalId,
                    (long long)st.nextUsn,
                    (long long)st.maximumSize);
            }
            else {
                wprintf(L"    [%s] no USN journal\n", v.c_str());
            }
        }
        return 0;
    }

    if (cmd == L"wipe") {
        for (auto& v : volumes) {
            UsnState saved{};
            bool haveSaved = PersistLoadState(v, saved);

            WipeUsnJournal(v.c_str());

            if (haveSaved) {
                RawPatchUsnJournal(v.c_str(), saved);
            }

            RestoreSystemTimestamps(v.c_str());
        }
        return 0;
    }

    if (cmd == L"restore") {
        for (auto& v : volumes) {
            UsnState saved{};
            if (PersistLoadState(v, saved)) {
                RawPatchUsnJournal(v.c_str(), saved);
                RestoreSystemTimestamps(v.c_str());
            }
        }
        return 0;
    }

    if (cmd == L"watch") {
        RunWatchdog(volumes);
        return 0;
    }

    if (cmd == L"status") {
        for (auto& v : volumes) {
            UsnState st{};
            if (QueryUsnState(v.c_str(), st)) {
                wprintf(L"    [%s] OldestEntry=0x%llX NextUsn=%lld Entries=%lld\n",
                    v.c_str(),
                    (unsigned long long)st.oldestEntry,
                    (long long)st.nextUsn,
                    (long long)st.entryCount);
            }
            else {
                wprintf(L"    [%s] no USN journal\n", v.c_str());
            }
        }
        return 0;
    }

    PrintBanner();
    return 1;
}