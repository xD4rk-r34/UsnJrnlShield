#pragma once
#include "UsnJournal.h"

bool RawPatchUsnJournal(const wchar_t* volume, const UsnState& state);