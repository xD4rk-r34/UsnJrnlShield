#pragma once
#include <windows.h>

bool RestoreSystemTimestamps(const wchar_t* volume);