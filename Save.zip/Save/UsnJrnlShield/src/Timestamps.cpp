#include <windows.h>
#include <string>
#include "Timestamps.h"
#include "Persist.h"

static const wchar_t* kTargets[] = {
    L"\\Windows\\System32\\winevt\\Logs\\System.evtx",
    L"\\Windows\\System32\\winevt\\Logs\\Security.evtx",
    L"\\Windows\\System32\\winevt\\Logs\\Application.evtx",
};

bool RestoreSystemTimestamps(const wchar_t* volume) {
    std::wstring root = volume;
    if (root.back() != L'\\') {
        root += L'\\';
    }

    for (auto rel : kTargets) {
        std::wstring full = root + rel;
        SavedTs ts{};
        if (!PersistLoadTimestamp(full, ts)) {
            continue;
        }

        HANDLE h = CreateFileW(full.c_str(),
            FILE_WRITE_ATTRIBUTES,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr, OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) {
            continue;
        }

        FILETIME cr{};
        FILETIME ac{};
        FILETIME wr{};
        cr.dwLowDateTime = (DWORD)ts.creation;
        cr.dwHighDateTime = (DWORD)(ts.creation >> 32);
        ac.dwLowDateTime = (DWORD)ts.access;
        ac.dwHighDateTime = (DWORD)(ts.access >> 32);
        wr.dwLowDateTime = (DWORD)ts.write;
        wr.dwHighDateTime = (DWORD)(ts.write >> 32);

        SetFileTime(h, &cr, &ac, &wr);
        CloseHandle(h);
    }
    return true;
}