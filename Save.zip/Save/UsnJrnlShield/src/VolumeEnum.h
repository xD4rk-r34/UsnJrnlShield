#pragma once
#include <windows.h>
#include <string>
#include <vector>

std::vector<std::wstring> EnumVolumes();