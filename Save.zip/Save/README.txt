==================================================
  UsnJrnlShield - USN Journal Timestamp Faker
==================================================

WHAT IT DOES
------------
- Wipes USN Journal on all drives
- Preserves "Oldest entry" timestamp so forensic
  tools (e.g. JournalTrace) cannot detect WHEN
  the logs were cleaned
- Works after wipe, after restart, and survives
  JournalTrace relaunches

REQUIREMENTS
------------
- Windows 10 / 11 x64
- Administrator rights
- Secure Boot MUST be disabled in BIOS/UEFI
- Test Mode MUST be enabled

INSTALLATION (first time)
-------------------------
1. Disable Secure Boot in BIOS/UEFI
2. Run install.bat as Administrator
3. Reboot Windows
4. After reboot, run:
       fltmc load UsnJrnlShieldDrv
5. Open cmd as Administrator, go to this folder:
       UsnJrnlShield.exe snapshot
   This saves the current "Oldest entry" as reference.

USAGE
-----
After installation, every time before cleaning logs:

    fltmc load UsnJrnlShieldDrv
    UsnJrnlShield.exe wipe
    UsnJrnlShield.exe restore

Now open JournalTrace - it will show the OLD date,
not the current one.

COMMANDS
--------
  UsnJrnlShield.exe snapshot   - save current state
  UsnJrnlShield.exe wipe       - wipe logs
  UsnJrnlShield.exe restore    - restore timestamps
  UsnJrnlShield.exe status     - show current state
  UsnJrnlShield.exe watch      - background watchdog

UNINSTALL
---------
1. Run uninstall.bat as Administrator
2. Reboot Windows
3. Re-enable Secure Boot in BIOS/UEFI

WARNING
-------
This driver works at kernel level. Test Mode reduces
system security. Use only on your own machine or in
lab environment. Do not use on production systems
without understanding the risks.