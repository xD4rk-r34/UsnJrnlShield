@echo off
title UsnJrnlShield Installer
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
    echo This script must be run as Administrator.
    pause
    exit /b 1
)

echo === 1. Installing certificate ===
certutil -addstore -f "Root" "%~dp0UsnJrnlShieldTest.cer"
certutil -addstore -f "TrustedPublisher" "%~dp0UsnJrnlShieldTest.cer"

echo === 2. Copying driver ===
copy /Y "%~dp0UsnJrnlShieldDrv.sys" "C:\Windows\System32\drivers\UsnJrnlShieldDrv.sys"

echo === 3. Installing INF ===
rundll32.exe setupapi.dll,InstallHinfSection DefaultInstall 132 "%~dp0UsnJrnlShieldDrv.inf"

echo === 4. Enabling Test Mode ===
bcdedit /set testsigning on
bcdedit /set nointegritychecks on

echo === 5. Loading driver ===
fltmc load UsnJrnlShieldDrv

echo.
echo === DONE ===
echo 1. Reboot Windows (required for Test Mode)
echo 2. After reboot, run:  fltmc load UsnJrnlShieldDrv
echo 3. Then run:  UsnJrnlShield.exe snapshot
pause