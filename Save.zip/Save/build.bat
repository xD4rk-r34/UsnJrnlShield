@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"

set WDK=C:\Program Files (x86)\Windows Kits\10
set WDKVER=10.0.22621.0
set MSVC=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC\14.44.35207
set SRC=C:\Users\kfkgj\Downloads\PassThroughShield

cd /d "%SRC%"

echo === Compiling passThrough.c ===
cl.exe /c /kernel /GS- /Gm- /Od /W4 /WX- /D_AMD64_ /D_WIN64 /DAMD64 /DWIN32=100 /DWINVER=0x0A00 /D_WIN32_WINNT=0x0A00 /DNTDDI_VERSION=0x0A000000 ^
  /I"%WDK%\Include\%WDKVER%\km" ^
  /I"%WDK%\Include\%WDKVER%\shared" ^
  /I"%WDK%\Include\%WDKVER%\ucrt" ^
  /Fo"passThrough.obj" ^
  passThrough.c

if errorlevel 1 (
    echo === COMPILE FAILED ===
    pause
    exit /b
)

echo === Linking UsnJrnlShieldDrv.sys ===
link.exe /DRIVER /SUBSYSTEM:NATIVE /ENTRY:GsDriverEntry /NODEFAULTLIB /INCREMENTAL:NO ^
  /OPT:NOREF /OPT:NOICF /DEBUG:FULL /FIXED:NO /DYNAMICBASE ^
  /ALIGN:4096 /FILEALIGN:512 ^
  /OUT:"%SRC%\UsnJrnlShieldDrv.sys" ^
  /LIBPATH:"%WDK%\Lib\%WDKVER%\km\x64" ^
  /LIBPATH:"%MSVC%\lib\x64" ^
  /LIBPATH:"%WDK%\Lib\%WDKVER%\km\shared" ^
  "%SRC%\passThrough.obj" ^
  fltMgr.lib ntoskrnl.lib hal.lib ntstrsafe.lib BufferOverflowK.lib wdmsec.lib libcntpr.lib

echo === Exit code: %ERRORLEVEL% ===
dir "%SRC%\UsnJrnlShieldDrv.sys"
pause