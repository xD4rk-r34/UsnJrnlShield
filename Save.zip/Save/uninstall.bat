@echo off
title UsnJrnlShield Uninstaller
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
    echo Run as Administrator.
    pause
    exit /b 1
)

echo === 1. Unloading driver ===
fltmc unload UsnJrnlShieldDrv

echo === 2. Stopping service ===
sc stop UsnJrnlShieldDrv
sc delete UsnJrnlShieldDrv

echo === 3. Removing driver file ===
del /F /Q "C:\Windows\System32\drivers\UsnJrnlShieldDrv.sys"

echo === 4. Removing certificate ===
certutil -delstore "Root" "UsnJrnlShieldTest"
certutil -delstore "TrustedPublisher" "UsnJrnlShieldTest"

echo === 5. Disabling Test Mode ===
bcdedit /set testsigning off
bcdedit /set nointegritychecks off

echo.
echo === DONE ===
echo Reboot Windows to complete removal.
pause